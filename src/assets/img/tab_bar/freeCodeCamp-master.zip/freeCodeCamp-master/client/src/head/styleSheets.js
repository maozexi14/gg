const styleSheets = [];

export default styleSheets;
