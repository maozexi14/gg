export default [
  {
    fields: {
      slug: '/super-block-one/block-a'
    },
    frontmatter: {
      block: 'Block A',
      title: 'Introduction to Block A'
    }
  },
  {
    fields: {
      slug: '/super-block-one/block-b'
    },
    frontmatter: {
      block: 'Block B',
      title: 'Introduction to Block B'
    }
  },
  {
    fields: {
      slug: '/super-block-one/block-c'
    },
    frontmatter: {
      block: 'Block C',
      title: 'Introduction to Block C'
    }
  }
];
