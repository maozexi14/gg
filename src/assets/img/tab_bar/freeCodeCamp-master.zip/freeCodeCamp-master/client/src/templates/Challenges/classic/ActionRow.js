import React from 'react';

import EditorTabs from './EditorTabs';

const ActionRow = () => (
  <div className='action-row'>
    <EditorTabs />
  </div>
);

ActionRow.displayName = 'ActionRow';

export default ActionRow;
