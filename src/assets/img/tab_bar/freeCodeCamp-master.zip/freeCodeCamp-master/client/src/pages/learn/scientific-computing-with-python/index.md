---
title: Scientific Computing with Python
superBlock: Scientific Computing with Python
---
## Introduction to Scientific Computing with Python

Learn the basics of Python.
