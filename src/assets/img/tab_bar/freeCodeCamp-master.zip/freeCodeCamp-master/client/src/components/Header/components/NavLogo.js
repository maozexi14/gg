import React from 'react';
import FreeCodeCampLogo from '../../../assets/icons/freeCodeCampLogo';

function NavLogo() {
  return <FreeCodeCampLogo />;
}

NavLogo.displayName = 'NavLogo';
export default NavLogo;
