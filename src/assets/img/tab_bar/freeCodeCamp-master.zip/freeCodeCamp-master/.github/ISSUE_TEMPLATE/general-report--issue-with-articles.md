---
name: 'Bug Report: Issues with /news or guide articles or documentation'
about: Report issue with a specific article, like broken links, typos, missing parts, etc
title: ''
labels: 'status: needs help for triage, type: bug'
assignees: ''

---

<!-- 
NOTE: If you want to become an author on freeCodeCamp, you can find everything here: https://www.freecodecamp.org/news/developer-news-style-guide/
-->

**Describe your problem and how to reproduce it:**


**Add a Link to the page with the problem:**


**Recommended fix, suggestions (how would you update it?):**


**If possible, add a screenshot here (you can drag and drop, png, jpg, gif, etc. in this box):**
