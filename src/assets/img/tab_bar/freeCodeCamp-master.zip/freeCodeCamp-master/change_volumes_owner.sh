#!/usr/bin/env bash

chown node:staff node_modules
chown node:staff api-server/node_modules
chown node:staff client/node_modules
chown node:staff client/plugins/fcc-create-nav-data/node_modules
chown node:staff curriculum/node_modules
chown node:staff tools/challenge-md-parser/node_modules
chown node:staff tools/scripts/seed/node_modules
