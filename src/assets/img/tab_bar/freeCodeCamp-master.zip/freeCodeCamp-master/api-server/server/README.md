Everything to do with the server.

One file that is not tracked here is `rev-manifest.json`.
It is generated at runtime and its contents change as the contents
of client side files change.
